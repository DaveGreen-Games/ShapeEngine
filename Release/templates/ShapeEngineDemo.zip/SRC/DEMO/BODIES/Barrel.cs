﻿

namespace $safeprojectname$.Bodies
{
    public class Barrel : Body
    {
    }
}
