﻿

namespace $safeprojectname$.Bodies
{
    internal class Enemy : Unit
    {
    }
}
